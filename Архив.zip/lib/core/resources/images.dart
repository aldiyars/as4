class Images {
  static String get splash => 'assets/images/splash_bg.png';
  static String get splash_1 => 'assets/images/splash_1.png';
  static String get splash_2 => 'assets/images/splash_2.png';
  static String get splash_3 => 'assets/images/splash_3.png';
  static String get splash_4 => 'assets/images/splash_4.png';
  static String get splash_5 => 'assets/images/splash_5.png';
  static String get personage_1 => 'assets/images/personage_1.png';
  static String get personage_2 => 'assets/images/personage_2.png';
  static String get personage_3=> 'assets/images/personage_3.png';
  static String get personage_4 => 'assets/images/personage_4.png';
  static String get personage_5 => 'assets/images/personage_5.png';
  static String get personage_6 => 'assets/images/personage_6.png';
}