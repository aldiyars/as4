
class SvgIcons {
  static String get personageMenu => 'assets/svg_icons/personage_menu.svg';
  static String get location => 'assets/svg_icons/location.svg';
  static String get episode => 'assets/svg_icons/episode.svg';
  static String get settings => 'assets/svg_icons/settings.svg';
  static String get grid => 'assets/svg_icons/grid.svg';
  static String get list => 'assets/svg_icons/list.svg';
}