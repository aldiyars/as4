class Routes {
  static const String initial_splash = '/';
  static const String home = '/home';
  static const String personage = '/personage';
}
