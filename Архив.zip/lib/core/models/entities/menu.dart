
class MenuEntity {
  final String title;
  final String icon;

  MenuEntity(this.title, this.icon);
}