
import 'package:flutter/material.dart';

class ColorPalette{
  static var darkPrimary = Color(0xff06121E);
  static var green = Color(0xff43D049);
  static var darkGray = Color(0xff5b6975);
  static var darkAccent = Color(0xff152A3A);
  static var white = Color(0xffffffff);
  static var red = Color(0xffEB5757);

}